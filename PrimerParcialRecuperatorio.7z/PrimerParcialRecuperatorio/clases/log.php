<?php
    class Log{
        public $ruta;
        public $metodo;
        public $hora;

        public function __construct($ruta, $metodo, $hora,$fecha){
            $this->ruta = $ruta;
            $this->metodo = $metodo;
            $this->hora = $hora;
            $this->fecha = $fecha;
        }

        public function toJSON(){
            return json_encode($this);
        }

        public static function alta($objeto){
            Archivo::guardarUno('./archivos/info.log', $objeto);
        }

        public static function retornarLogs(){
            $datos = Archivo::leerArchivo('./archivos/info.log');
            $logs = array();
            foreach ($datos as $key => $value) {
                $log = new Log($value->ruta, $value->metodo, $value->hora, $value->fecha);
                array_push($logs, $log);
            }
            return $logs;
        }

        public static function filtrarPorFecha($fecha){
            $logs = array();
            $datos = Log::retornarLogs();
            foreach ($datos as $key => $value) {
                if($value->fecha > $fecha){
                    $log = new Log($value->ruta, $value->metodo, $value->hora, $value->fecha);
                    array_push($logs, $log);
                }
            }
            array_map('Log::mostrarLog', $logs);
        }

        public static function mostrarLog($objeto){
            echo $objeto->toJSON() . PHP_EOL;
        }
    }
?>