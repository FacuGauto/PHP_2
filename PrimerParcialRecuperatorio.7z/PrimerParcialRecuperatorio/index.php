<?php
    date_default_timezone_set('America/Argentina/Buenos_Aires');

    use \Psr\Http\Message\ServerRequestInterface as Request;
    use \Psr\Http\Message\ResponseInterface as Response;

    require_once './vendor/autoload.php';
    require_once './clases/pizza.php';
    require_once './clases/archivo.php';
    require_once './clases/venta.php';
    require_once './clases/log.php';

    function guardarLog($metodo, $ruta){
        $hora = date("h:i:s");
        $date = date("Ymd");
        $log = new Log($ruta, $metodo, $hora,$date);
        Log::Alta($log);
    }

    $config['displayErrorDetails'] = true;
    $config['addContentLengthHeader'] = false;
    
    $app = new \Slim\App(["settings" => $config]);

    $app->post('/pizzas', function(Request $request, Response $response, array $args){
        guardarLog($request->getMethod(), $request->getUri()->getPath());

        $arrDatos = $request->getParsedBody();
        $arrImg = $request->getUploadedFiles();
        if(isset($arrDatos['precio'], $arrDatos['tipo'], $arrDatos['cantidad'], $arrDatos['sabor'])){
            if(!empty($arrDatos['precio']) && !empty($arrDatos['tipo']) && !empty($arrDatos['sabor']) && !empty($arrDatos['cantidad'])){
                if($arrImg['imagen'] != null && $arrImg['foto'] != null){
                    $tipo = $arrDatos['tipo']; $sabor = $arrDatos['sabor']; 
                    $precio = $arrDatos['precio']; $cantidad = $arrDatos['cantidad'];
                    if(Pizza::validarTipo($tipo)){
                        if(Pizza::validarSabor($sabor)){
                            if(!Pizza::validarCombinacion($tipo, $sabor)){
                                $id = Pizza::generarNuevoId();
                                // Imagen
                                $origen = $arrImg['imagen']->file;
                                $nombreImagen = $arrImg['imagen']->getClientFilename();
                                $ext = pathinfo($nombreImagen, PATHINFO_EXTENSION);
                                $destinoImagen = "./images/pizzas/".$id."-imagen.".$ext;
                                move_uploaded_file($origen, $destinoImagen);
                                //Foto
                                $origen2 = $arrImg['foto']->file;
                                $nombreFoto = $arrImg['foto']->getClientFilename();
                                $ext2 = pathinfo($nombreFoto, PATHINFO_EXTENSION);
                                $destinoFoto = "./images/pizzas/".$id."-foto.".$ext2;
                                move_uploaded_file($origen2, $destinoFoto);

                                $pizza = new Pizza($id, $precio, $tipo, $cantidad, $sabor, $destinoImagen, $destinoFoto);
                                Pizza::alta($pizza);
                                echo '{"mensaje":"Se guardo correctamente"}';
                            }else   
                                echo '{"mensaje":"La combinación ya existe"}';  
                        }else
                            echo '{"mensaje":"Ingrese un sabor válido"}';   
                    }else
                        echo '{"mensaje":"Ingrese un tipo válido"}';
                }else
                    echo '{"mensaje":"Debe ingresar 2 imagenes"}';
            }else   
                echo '{"mensaje":"No puede haber campos vacios"}';
        }else
            echo '{"mensaje":"Faltan datos"}';
    });

    $app->get('/pizzas', function(Request $request, Response $response, array $args){
        guardarLog($request->getMethod(), $request->getUri()->getPath());

        $arrDatos = $request->getQueryParams();
        if(isset($arrDatos['tipo'], $arrDatos['sabor']) && !empty($arrDatos['tipo']) && !empty($arrDatos['sabor'])){
            if(Pizza::validarTipo($arrDatos['tipo'])){
                if(Pizza::validarSabor($arrDatos['sabor'])){
                    Pizza::mostrarDisponible($arrDatos['tipo'], $arrDatos['sabor']);
                }else
                    echo '{"mensaje":"Ingrese un sabor valido"}'; 
            }else
                echo '{"mensaje":"Ingrese un tipo valido"}';
        }else
            echo '{"mensaje":"Ingrese tipo y sabor"}';
    });

    $app->post('/ventas', function(Request $request, Response $response, array $args){
        guardarLog($request->getMethod(), $request->getUri()->getPath());
        $datos = $request->getParsedBody();
        if(isset($datos['email'], $datos['tipo'], $datos['sabor'], $datos['cantidad'])){
            $email = $datos['email']; $tipo = $datos['tipo']; $sabor = $datos['sabor']; $cantidad = $datos['cantidad'];
            if(!empty($email) && !empty($tipo) && !empty($sabor) && !empty($cantidad)){
                if(Pizza::validarTipo($tipo)){
                    if(Pizza::validarSabor($sabor)){
                        if(Pizza::validarCombinacion($tipo, $sabor)){
                            $pizzas = Pizza::retornarPizzas();
                            foreach($pizzas as $item){
                                if(strcasecmp($item->sabor, $sabor) == 0 && strcasecmp($item->tipo, $tipo) == 0){
                                    if($item->cantidad > 0 && $item->cantidad > $cantidad){
                                        $item->cantidad--;
                                        $id = Venta::generarNuevoId();
                                        $precio = $item->precio * $cantidad;
                                        $venta = new Venta($id, $email, $tipo, $cantidad, $sabor, $precio);
                                        Venta::alta($venta);
                                        echo '{"mensaje":"Se realizo la venta"}';
                                    }else   
                                        echo '{"mensaje":"No hay la cantidad necesaria"}';
                                }   
                            }
                            archivo::guardarTodos('./archivos/pizzas.txt', $pizzas);
                            
                        }else
                            echo '{"mensaje":"No existe la combinacion"}';
                    }else
                        echo '{"mensaje":"Ingrese un sabor valido"}';
                }else
                    echo '{"mensaje":"Ingrese un tipo valido"}';
                
            }else
                echo '{"mensaje":"No puede haber campos vacíos"}';
        }else
            echo '{"mensaje":"Complete todos los campos requeridos"}';
    });

    $app->post('/pizzasModificar', function(Request $request, Response $response, array $args){
        guardarLog($request->getMethod(), $request->getUri()->getPath());

        $datos = $request->getParsedBody();
        $img = $request->getUploadedFiles();
        
        if(isset($datos['precio'], $datos['tipo'], $datos['sabor'], $datos['cantidad'], $datos['id'])){
            $tipo = $datos['tipo']; $sabor = $datos['sabor']; $cantidad = $datos['cantidad']; $id = $datos['id'];
            if(!empty($tipo) && !empty($sabor) && !empty($cantidad) && !empty($id)){
                if($img['imagen'] != null && $img['foto'] != null){
                    if(Pizza::validarTipo($tipo)){
                        if(Pizza::validarSabor($sabor)){
                            if(Pizza::existeId($id)){
                                Pizza::modificar($datos, $img);
                            }else
                                echo '{"mensaje":"No existe pizza con ese id"}';
                        }else
                            echo '{"mensaje":"Ingrese un sabor valido"}';
                    }else
                        echo '{"mensaje":"Ingrese un tipo valido"}';
                }else
                    echo '{"mensaje":"Debe ingresar 2 imagenes"}';
            }else
                echo '{"mensaje":"No puede haber campos vacíos"}';
        }else
            echo '{"mensaje":"Complete todos los campos requeridos"}';
    });

    $app->get('/ventas', function(Request $request, Response $response, array $args){
        guardarLog($request->getMethod(), $request->getUri()->getPath());

        $arrDatos = $request->getQueryParams();
        if(isset($arrDatos['tipo']) || isset($arrDatos['sabor'])){
            /*if(!empty($arrDatos['tipo'])){
                if(Pizza::validarTipo($arrDatos['tipo'])){
                    Venta::filtrarPorTipo($arrDatos['tipo']);
                }else
                    echo '{"mensaje":"Ingrese un tipo valido"}';
            }*/
            /*if(!empty($arrDatos['sabor'])){
                if(Pizza::validarSabor($arrDatos['sabor'])){
                    //Venta::filtrarPorSabor($arrDatos['sabor']);
                }else
                    echo '{"mensaje":"Ingrese un sabor valido"}';
            }*/
            if(!empty($arrDatos['tipo']) && !empty($arrDatos['sabor'])){
                if(Pizza::validarSabor($arrDatos['sabor']) && Pizza::validarTipo($arrDatos['tipo'])){
                    Venta::filtrarPorTipoySabor($arrDatos['tipo'],$arrDatos['sabor']);
                }else{
                    echo '{"mensaje":"Ingrese un sabor  y tipo valido"}';
                }
            }
        }else
            echo '{"mensaje":"Ingrese tipo o sabor"}';
    });

    $app->delete('/pizzas', function(Request $request, Response $response, array $args){
        guardarLog($request->getMethod(), $request->getUri()->getPath());
        $datos = $request->getParsedBody();
        if(isset($datos['id']) && !empty($datos['id'])){
            if(Pizza::existeId($datos['id'])){
                Pizza::borrar($datos['id']);
            }else
                echo '{"mensaje":"No existe pizza con ese Id"}';
        }else
            echo '{"mensaje":"Ingrese un id valido"}';
    });

    $app->get('/logs', function(Request $request, Response $response, array $args){
        $arrDatos = $request->getQueryParams();
        if(isset($arrDatos['fecha']) && !empty($arrDatos['fecha'])){
            Log::filtrarPorFecha($arrDatos['fecha']);
        }else
            echo '{"mensaje":"Ingrese un fecha"}';
    });

    $app->run();
?>