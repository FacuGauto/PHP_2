<?php

use Slim\App;
use Slim\Http\Request;
use Slim\Http\Response;
use App\Models\ORM\usuario;
use App\Models\ORM\usuarioApi;


include_once __DIR__ . '/../../src/app/modelORM/usuario.php';
include_once __DIR__ . '/../../src/app/modelORM/usuarioControler.php';

return function (App $app) {
    $container = $app->getContainer();

     $app->group('/usuario', function () {   
         
        $this->get('/', function ($request, $response, $args) {
          //echo "EEEEEEEEEEE";
          //return cd::all()->toJson();
          $todosLosUsuarios=usuario::all();
          //var_dump($todosLosUsuarios);
          //$todosLosCds= new cd;
          //$todosLosCds->titel = "Nuevo titulo";
          //$todosLosCds->save();
          $newResponse = $response->withJson($todosLosUsuarios, 200);  
          return $newResponse;
        });
        $this->post('/', function ($request, $response, $args) {
          $arry_params = $request->getParsedBody();
          $usuario= new usuario;
          $usuario->email = $arry_params['email'];
          $usuario->clave = $arry_params['clave'];
          $usuario->tipo = $arry_params['tipo'];
          $usuario->legajo = $arry_params['legajo'];
          $usuario->save();
          $newResponse = $response->withJson($usuario, 200);  
          return $newResponse;
        });
    });


     $app->group('/cdORM2', function () {   

        $this->get('/',cdApi::class . ':traerTodos');
   
    });

};