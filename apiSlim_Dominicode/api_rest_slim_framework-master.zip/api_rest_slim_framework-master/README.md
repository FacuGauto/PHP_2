# Creación de una RESTFUL API o API REST con slim framework (PHP, MySql, PDO)

Creación de una RESTFUL API o API REST con slim framework (PHP, MySql, PDO)

Slim es un micro-framework PHP, que te ayuda a crear API de manera rápida pero rubusta.

En esencia, Slim es un despachador que recibe una solicitud HTTP, invoca una rutina de devolución de la llamada apropiada y devuelve una respuesta HTTP.

Si, quieres ver como lo hice aquí lo puedes ver 
https://www.youtube.com/watch?v=iLRjbGC6jIs

¿Que es es REST?

REST son las siglas de Representational State Transfer. Fue definido hace una década por Roy Fielding en su tesis doctoral, y proporciona una forma sencilla de interacción entre sistemas, la mayor parte de las veces a través de un navegador web y HTTP. Esta cohesión con HTTP viene también de que Roy es uno de los principales autores de HTTP.

REST es un estilo arquitectónico, un conjunto de convenciones para aplicaciones web y servicios web, que se centra principalmente en la manipulación de recursos a través de especificaciones HTTP. Podemos decir que REST es una interfaz web estándar y simple que nos permite interactuar con servicios web de una manera muy cómoda.



Facebook: https://www.facebook.com/dominicodee/

Twitter : https://twitter.com/domini_code

Suscribete al canal: https://www.youtube.com/c/DominiCode?sub_confirmation=1 

